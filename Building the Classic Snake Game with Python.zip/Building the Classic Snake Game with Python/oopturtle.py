import turtle

myturtle  = turtle.Turtle()

myturtle.shape("turtle")
myturtle.color("red")



myturtle.forward(100)

turtle.done()

